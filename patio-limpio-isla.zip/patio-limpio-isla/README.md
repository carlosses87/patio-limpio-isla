# Patio Limpio Isla – Landing Page

Página web profesional lista para usar.

## Cómo publicarla GRATIS (elige una opción)

### Opción 1: Netlify (la más fácil)
1. Entra a https://www.netlify.com y crea cuenta gratis (puedes con Google).
2. Arrastra toda la carpeta `patio-limpio-isla` a la zona de "Drag and drop".
3. ¡Listo! Te da un link tipo `https://algo-random.netlify.app`
4. Puedes personalizar el nombre del sitio en Settings → Domain.

### Opción 2: Vercel
1. Entra a https://vercel.com y crea cuenta.
2. Sube la carpeta o conéctala desde GitHub.
3. Te da un link gratis.

### Opción 3: GitHub Pages
1. Crea un repositorio en GitHub.
2. Sube los archivos (`index.html`, `logo.jpg`).
3. Ve a Settings → Pages → Source: main branch.
4. Tu página quedará en `https://tuusuario.github.io/nombre-repo`

---

## Archivos incluidos
- `index.html` → La página completa
- `logo.jpg` → Tu logo
- `flyer.jpg` → Tu flyer (por si lo quieres usar después)

---

## Personalización rápida
Si quieres cambiar el número de WhatsApp o textos, abre `index.html` con cualquier editor de texto (Bloc de notas, VS Code, etc.) y busca las partes que quieras modificar.
